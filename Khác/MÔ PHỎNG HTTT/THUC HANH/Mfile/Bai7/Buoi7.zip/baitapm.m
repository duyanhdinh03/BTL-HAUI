x=0:0.01:10;
y=sin(x) + 3*cos(2*x);
plot(x,y)